1. drawable 파일 에 PNG 파일 5개를 넣음
2. menu 파일에 bottom_navigation_menu를 넣음 (menu 파일이 없다면 생성)
3. layout 파일 main과 favorite을 넣음